def generate_summary():
    return {
        "title": "Sample Summary",
        "content": "This is a generated English memory summary."
    }

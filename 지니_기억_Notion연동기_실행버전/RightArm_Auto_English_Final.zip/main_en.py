import os
from modules.memory_parser import generate_summary
from modules.notion_uploader import upload_to_notion
import json
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(BASE_DIR, 'config', 'config_en.json')
BACKUP_PATH = os.path.join(BASE_DIR, 'data', 'memory_backup_en.json')
LOG_PATH = os.path.join(BASE_DIR, 'logs', 'upload_log_en.txt')

# ensure folders exist
os.makedirs(os.path.dirname(BACKUP_PATH), exist_ok=True)
os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)

summary = generate_summary()
with open(BACKUP_PATH, 'w', encoding='utf-8') as f:
    json.dump(summary, f, ensure_ascii=False, indent=2)

upload_result = upload_to_notion(summary, CONFIG_PATH)

with open(LOG_PATH, 'a', encoding='utf-8') as log_file:
    log_file.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] Upload status: {upload_result}\n")

print("✅ English memory summary uploaded successfully.")

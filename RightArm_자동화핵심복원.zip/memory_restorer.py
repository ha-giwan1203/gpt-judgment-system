def load_restore_prompt(file_path="restore_prompt.txt"):
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            prompt = f.read()
        print("✅ 복원 프롬프트 로드 완료")
        print(prompt)
    except FileNotFoundError:
        print("❌ restore_prompt.txt 파일이 없습니다.")

if __name__ == "__main__":
    load_restore_prompt()

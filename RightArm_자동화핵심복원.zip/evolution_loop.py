import os
from evolution_planner import extract_state, suggest_plan

def run_loop():
    print("📌 복원 프롬프트 기반 실행 루프")
    try:
        with open("restore_prompt.txt", "r", encoding="utf-8") as f:
            prompt = f.read()
    except:
        print("❌ restore_prompt.txt 누락")
        return

    modules = extract_state(prompt)
    goals = suggest_plan(modules)

    for i, goal in enumerate(goals, 1):
        print(f"{i}. {goal}")

if __name__ == "__main__":
    run_loop()

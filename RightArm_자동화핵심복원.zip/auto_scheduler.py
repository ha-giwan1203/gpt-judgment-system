import schedule
import time
import os
from datetime import datetime

def run():
    print(f"[{datetime.now()}] ▶ 자동 복원 + 루프 실행")
    os.system("python memory_restorer.py")
    os.system("python evolution_loop.py")

schedule.every().day.at("08:00").do(run)

print("⏰ 스케줄러 시작 (매일 08:00)")
while True:
    schedule.run_pending()
    time.sleep(60)

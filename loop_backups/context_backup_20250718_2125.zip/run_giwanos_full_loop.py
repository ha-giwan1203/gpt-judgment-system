import os

def run_giwanos_loop():
    print("🔁 [1/5] 회고 마크다운 생성 중...")
    os.system("python auto_generate_reflection.py")

    print("📄 [2/5] 회고 PDF 변환 중...")
    os.system("python generate_reflection_pdf.py")

    print("📤 [3/5] 회고 Notion 전송 중...")
    os.system("python upload_notion_reflection.py")

    print("📦 [4/5] ZIP 백업 생성 중...")
    os.system("python zip_backup_generator.py")

    print("✅ [5/5] GIWANOS 루프 전체 완료")

if __name__ == "__main__":
    run_giwanos_loop()
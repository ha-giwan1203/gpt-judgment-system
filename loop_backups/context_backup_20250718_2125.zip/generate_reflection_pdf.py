import os
import warnings
from fpdf import FPDF
from datetime import datetime

warnings.filterwarnings("ignore")  # cmap/glyph 경고 제거

now = datetime.now().strftime("%Y%m%d_%H%M")
input_path = "reflections/loop_reflection_log.md"
output_path = f"reflections/loop_reflection_log_{now}.pdf"

font_path = "C:/giwanos/Nanum_Gothic/NotoSansKR-Regular.ttf"
font_name = "NotoSansKR"

class PDF(FPDF):
    def __init__(self):
        super().__init__()
        self.add_font(font_name, "", font_path, uni=True)
        self.set_auto_page_break(auto=True, margin=15)
        self.add_page()

    def header(self):
        self.set_font(font_name, "", 14)
        self.cell(0, 10, "GIWANOS 회고 보고서", ln=True, align="C")

    def chapter_body(self, text):
        self.set_font(font_name, "", 12)
        self.multi_cell(0, 8, text)

pdf = PDF()

if not os.path.exists(input_path):
    print("❌ 회고 마크다운 파일이 없습니다.")
    exit(1)

with open(input_path, "r", encoding="utf-8") as f:
    md_text = f.read()

pdf.chapter_body(md_text)
pdf.output(output_path)
print(f"✅ 회고 PDF 생성 완료 → {output_path}")
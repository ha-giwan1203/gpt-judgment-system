import os
import subprocess

print("▶ GIWANOS 전체 루프 시작")

subprocess.run(["python", "auto_generate_reflection.py"])
subprocess.run(["python", "generate_reflection_pdf.py"])
subprocess.run(["python", "upload_final_runner.py"])
subprocess.run(["python", "giwanos_backup_loop.py"])

print("✅ 전체 루프 완료")
